<?php
header('Access-Control-Allow-Origin: *'); // instead of * 127.0.0.1:4200
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
//header('Content-Type: text/plain');

// Options only needs the header
if ($_SERVER['REQUEST_METHOD']==='OPTIONS'){
    die;
}

// Verify token
$token = $_GET['token'];
if ($token !== 'amPuVeGm4ucm/qwA8q6g3FR57f7TYj1PKjwTpzMZBiY='){
    echo '{"error" : "Invalid token"}';
    die;
}


if (isset ($_GET['file'])){
    if ($_GET['file']== '2') {
        $type1 = explode ("\r\n",file_get_contents ('chemical_type_2.csv'));
    } else {
        $type1 = explode ("\r\n",file_get_contents ('chemical_type_1.csv'));        
    }
} else {
    $type1 = explode ("\r\n",file_get_contents ('chemical_type_1.csv'));
}
array_shift ($type1);

// Built to be short, no error checking or optimization
if (isset ($_GET['search'])){
    $search = strtoupper($_GET['search']); 
    $limit = 20;
    $offset = 0;
    if (isset ($_GET['limit'])){$name = intVal ($_GET['limit']);}
    if (isset ($_GET['offset'])){$offset = intval ($_GET['offset']);}
    $results = "[";
    $resultsCount = 0;
    foreach ($type1 as $row) {   
        if (strpos (strtoupper($row),$search) !== false) {
            $temp = explode (';',$row);
            if ( $resultsCount>$offset && ($resultsCount < ($offset + $limit))){
                $results.=',';
            }
            if (($resultsCount >= $offset) && ($resultsCount < ($offset + $limit))) {
                $results.="\r\n".'{"patent no":"'.$temp[0].'",'.'"patent title":"'.$temp[1].'","chemical type 1":"'.$temp[2].'"}';
              }
            $resultsCount++;
        }
    }
    $results.=']';  
    echo '{ "count" : '.$resultsCount.', "results": '.$results.', "offset" : '.$offset.', "limit" : '.$limit.'}';
}
else {
    echo ('{}');
}
